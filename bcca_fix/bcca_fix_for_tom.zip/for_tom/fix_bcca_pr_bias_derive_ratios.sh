#!/bin/bash

#calculates and applies a smoothed monthly bias correction to the mean

OBSD="/data3/emaurer/usbr/bcca_check/obs" #where processed obs file is
GCMROOTDIR="/data3/emaurer/usbr/bcca_check/gcm_bcca" #root dir for daily data
WORKINGDIR="./junk"
GCM="ACCESS1-0"
#GCM="CCSM4"
ENS="r1i1p1"
V="pr"

[ -d ${WORKINGDIR} ] || mkdir ${WORKINGDIR}

#Directory structure on ftp server like this: bcca/access1-0/rcp85/day/r1i1p1/pr/
# and bcca/access1-0/historical/day/r1i1p1/pr/
GCMLOWER=`awk -v x=${GCM} 'BEGIN{print tolower(x)}'`

OBSF=${OBSD}/obs_${V}_1950-1999_monthly_12values.nc

GCMD=${GCMROOTDIR}/${GCMLOWER}/historical/day/${ENS}/${V}

#STEP 1: take monthly mean of daily BCCA files, concatenate to one file
OFSTR=''
for SY in 1950 1960 1970 1980 1990; do
    EY=`expr $SY + 9`
    IF=${GCMD}/BCCA_0.125deg_${V}_day_${GCM}_historical_${ENS}_${SY}0101-${EY}1231.nc
    OF=${WORKINGDIR}/junk_${GCM}_${V}_${ENS}_${SY}-${EY}_monthly.nc
    OFSTR="${OFSTR} ${OF}"
    cdo monmean $IF $OF
done
OF1=${WORKINGDIR}/${GCM}_${V}_${ENS}_1950-1999_monthly.nc
cdo cat ${OFSTR} ${OF1}
\rm -f ${OFSTR}
echo "created ${OF1}"

#STEP 2: take running mean of monthly values to smooth transitions between months
#NOTE: TIME STEPS NO LONGER BEGIN WITH JAN - MAYBE NOT A PROBLEM, YMONMUL KEEPS TRACK?
OF2=${WORKINGDIR}/${GCM}_${V}_${ENS}_1950-1999_monthly_runmean.nc
cdo runmean,3 ${OF1} ${OF2}
echo "created ${OF2}"

#STEP 3: Calculate multi-year monthly mean value
OF3=${WORKINGDIR}/${GCM}_${V}_${ENS}_1950-1999_monthly_12values.nc
cdo ymonmean ${OF2} ${OF3}
echo "created ${OF3}"

#STEP 4: Divide observed 12 values by calculated values to get correction ratio
OF4=${WORKINGDIR}/${GCM}_${V}_${ENS}_1950-1999_monthly_12correctionratios.nc
cdo div ${OBSF} ${OF3} ${OF4}
echo "created ${OF4}"
