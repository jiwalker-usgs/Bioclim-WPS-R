#!/bin/bash

#Uses output from fix_bcca_pr_bias_derive_ratios.sh
#directories assumed to be the same
#applies a smoothed monthly bias correction to the mean

OBSD="/data3/emaurer/usbr/bcca_check/obs" #where processed obs file is
GCMROOTDIR="/data3/emaurer/usbr/bcca_check/gcm_bcca" #root dir for daily data
OUTROOTDIR="/data3/emaurer/usbr/bcca_check/gcm_bcca_corrected" #root dir for CORRECTED daily data
WORKINGDIR="./junk"
GCM="ACCESS1-0"
#GCM="CCSM4"
ENS="r1i1p1"
RCP="rcp85"
V="pr"

#warning cdo ymonmul (Warning): Grid longitudes differ!
#becuase of mixing -180 -> 180 and 0 -> 360 grids. Seems to work fine anyway.

[ -d ${OUTROOTDIR} ] || mkdir ${OUTROOTDIR}

CORRF=${WORKINGDIR}/${GCM}_${V}_${ENS}_1950-1999_monthly_12correctionratios.nc

#Directory structure on ftp server like this: bcca/access1-0/rcp85/day/r1i1p1/pr/
# and bcca/access1-0/historical/day/r1i1p1/pr/
GCMLOWER=`awk -v x=${GCM} 'BEGIN{print tolower(x)}'`

#locations of daily GCM data
GCMD=${GCMROOTDIR}/${GCMLOWER}/historical/day/${ENS}/${V}
GCMD2=${GCMROOTDIR}/${GCMLOWER}/${RCP}/day/${ENS}/${V}

#STEP 1: create list of files to apply correction to daily historical files
FLIST=`ls -1 ${GCMD} | grep \.nc `

for IF in ${FLIST}; do
    echo "correcting ${IF}"
    OF=${IF/'.nc'/'_corr.nc'}
    cdo ymonmul ${GCMD}/${IF} ${CORRF} ${OUTROOTDIR}/${OF}
done
